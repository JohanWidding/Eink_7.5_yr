/*****************************************************************************
* | File      	:   Readme_CN.txt
* | Author      :   Waveshare team
* | Function    :   Help with use
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2020-02-19
* | Info        :   Provide a Chinese version of the documentation here for your quick use
******************************************************************************/
This file is to help you use this routine.

1. Basic information:
This routine is developed based on Arduino. The routines have been verified on the E-Paper ESP32 Driver Board;

2. Basic use:
     Copy the entire esp32-waveshare-epd folder to the \ hardware \ espressif \ esp32 \ libraries folder in the Arduino installation path
     Then open the Arduino IDE, find wareshare-e-Paper in the file = "example =", open the corresponding demo, and download it to the E-Paper ESP32 Driver Board.
